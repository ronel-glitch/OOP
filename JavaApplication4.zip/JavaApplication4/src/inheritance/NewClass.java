/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

/**
 *
 * @author user
 */
import java.util.Scanner;
public class NewClass {
    public static int area1,area2,volume1,volume2;
    
    public static class rectangle2 {
        
        public int area;
        public int length;
        public int width;
        
         
        
         public int getArea(){
             area = length*width;
             return area;
         }
         
         public int getWidth(){
             
             return width;
        }
         
         public int getLength(){
             area = length*width;
             return length;
         }
         
         
         public void setLength(int length){
             
             this.length=length;
         } 
         
         public void setWidth(int width){
             
             this.width=width;
         }
        
            public void equals(){
             if(volume1 == volume2){
                 System.out.println("True");
             }
             
             else
                 System.out.println("False");
             
          
         }
         
         
         public String toString(){ 
             
             return "Box: length = " + length + " , width = " + width;
         }        
        
    }
    
    class triangle2{
       
        private int length;
        private int width;
        
    }
    
    public static class Box extends rectangle2{
        
        private int heigth;
        
        
        
        public int getHeigth() {
            return heigth;
        }
        
        public void setHeigth(int heigth){
            this.heigth=heigth;
        }
        
          
        
        public void Box(int l, int w,int h){
            
            Box box = new Box();
            super.getLength();          
            super.getWidth();
            box.getHeigth();
            super.setLength(l);
            super.setWidth(w);
            box.setHeigth(h);          
          
        }
        
        public String toString(){ 
             
             return "Box: length = " + getLength() + " , width = " + getWidth() + " , heigth = " +getHeigth();
         }        
         public int getArea(){          
            int area=0;
             area= (2*getLength()*getWidth())+(2*getLength()*getHeigth())+(2*getWidth()*getHeigth());
             this.area = area;
            return area;
        }
         
         public void equals(){
             if(area1 == area2){
                 System.out.println("True");
             }
             
             else
                 System.out.println("False");
             
          
         }

        
    }
     public static void main(String[] args){ 
         
         Scanner scan = new Scanner(System.in);
         Box box = new Box();
         box.setLength(2);
         box.setWidth(3);
         box.setHeigth(4);
         System.out.println("Box A = "+box.toString());
         System.out.println("BOX A surface area: "+box.getArea());
         area1=box.getArea();
         box.setLength(4);
         box.setWidth(7);
         box.setHeigth(4);
         System.out.println("Box B = "+box.toString());
         System.out.println("BOX B surface area: "+box.getArea());
         area2=box.getArea();
         System.out.print ("Check if box a and box b are equal? ");
         box.equals();
        
         
     }
    
}
